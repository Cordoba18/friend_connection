<?php

namespace App\Http\Controllers;

use App\Models\Publication;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use Carbon\Carbon;
class PublicationController extends Controller
{

    public function __construct()
    {

        $this->middleware('auth');
    }
    public function index()
    {
        $user = Auth::user();
        $my_publications = DB::select("SELECT * FROM publications WHERE id_user =".Auth::user()->id. " AND id_state = 1 LIMIT 5");
        $publications = DB::select("SELECT u.id, u.name, u.picture, p.picture AS picture_publication, p.description, p.date
         FROM publications p
        INNER JOIN users u ON p.id_user = u.id
         WHERE p.id_user <>".Auth::user()->id." AND p.id_state = 1 AND u.id_state = 1 ORDER BY p.id DESC");
        $likes = DB::select("SELECT * FROM likes WHERE id_state = 1");
        $comments = DB::select("SELECT * FROM comments WHERE id_state = 1");
        $city = DB::selectOne("SELECT c.city FROM users u
        INNER JOIN citys c ON u.id_city = c.id
        WHERE u.email = '$user->email'");
        return view('customprofile', compact('user', 'city', 'my_publications', 'publications', 'likes','comments'));
    }

    public function loading_departaments()
    {
        $departaments = DB::select('SELECT * FROM departaments');
        return response()->json(['message' => $departaments], 200);
    }

    public function loading_citys($id)
    {
        $citys = DB::select("SELECT * FROM citys WHERE id_departament = $id");
        return response()->json(['message' => $citys], 200);
    }

    public function loading_dates_user()
    {
        $user = Auth::user();
        return response()->json(['message' => $user], 200);
    }

    public function save_dates_user(Request $request)
    {
        $user = User::find(Auth::user()->id);
        if ($request->name !== null) {

            $user->name = $request->name;
        }
        if ($request->hasFile('image')) {

            $imagen = $request->file('image');
            $fechaHoraActual = now()->format('Y-m-d_H-i-s');
            $nombreImagen = $fechaHoraActual . '_' . $imagen->getClientOriginalExtension();
            $rutaImagen = storage_path('app/public/imgs/' . $nombreImagen);
            $imagen->move(storage_path('app/public/imgs'), $nombreImagen);
            $user->picture = $nombreImagen;
        }
        if ($request->phone !== null) {
            $user->phone = $request->phone;
        }
        if ($request->city !== null) {
            $user->id_city = $request->city;
        }
        if ($request->birthdate !== null) {
            $user->birthdate = $request->birthdate;
        }
        $user->save();
        return redirect()->route('home')->with('dates_user', 'bien guardados');
    }

    public function save_publication(Request $request)
    {


        $new_publication = new Publication();

        if ($request->description == null || $request->hasFile('image')==false) {
            return redirect()->route('home')->with('error_dates_publication', 'error de datos');
        }else{
        if ($request->hasFile('image')) {

            $imagen = $request->file('image');
            $fechaHoraActual = now()->format('Y-m-d_H-i-s');
            $nombreImagen = $fechaHoraActual . '_' . $imagen->getClientOriginalExtension();
            $rutaImagen = storage_path('app/public/imgs/' . $nombreImagen);
            $imagen->move(storage_path('app/public/imgs'), $nombreImagen);
            $fechaActual = Carbon::now();
            $fechaActual->setLocale('es');
            $fechaColombiana = $fechaActual->format('F d Y');
            $new_publication->description = $request->description;
            $new_publication->picture= $nombreImagen;
            $new_publication->id_user = Auth::user()->id;
            $new_publication->id_state = 1;
            $new_publication->date = $fechaColombiana;
            $new_publication->save();
            return redirect()->route('home')->with('succes_dates_publication', 'good datos');

        }
    }

    }


}
