@extends('layouts.main')
@section('title', 'HOME')

@section('css')
    @vite(['resources/css/home.css'])
@endsection


@section('content')
    @csrf

    <div class="contenido">



    </div>

    @if ($user->name == null || $user->phone == null || $user->id_city == null || $user->birthdate == null)
        <p id="info_validate_dates" hidden>TRUE</p>
        <div class="warning">
            <div class="content_warning">
                <i id="btn_x" class="bi bi-x-circle"></i>
                <div class="message_Warning">
                    <div class="content_logo_message_Warning">
                        <img src="{{ asset('storage/icons/logo_FD.png') }}" alt="">
                    </div>
                    <h1>BIENVENIDO A FRIEND CONNECTION!</h1>
                    <p>Porfavor completa tu informacion de perfil para realizar publicaciones.</p>
                </div>
            </div>
    @endif

    </div>
    <header class="navbar">
        <div class="content-logo-navbar">
            <img src="{{ asset('storage/icons/logo_FD.png') }}" alt="">
        </div>
        <h1>FRIEND CONNECTION</h1>
        <button id="btn_open_menu"><i class="bi bi-person-circle"></i></button>
        <div class="menu" hidden>
            <button>MIS FOTOS</button>
            <button>EDITAR DATOS</button>
            <button>CERRAR SESION</button>
        </div>
    </header>
    <section class="content-home">

        <div class="content-left">
            <div class="content-profile">
                <div class="content-my-picture">
                    <center>
                        @if ($user->picture == null and $user->id_gender == 1)
                            <img id="my_image" src="{{ asset('storage/imgs/avatar_men.png') }}" alt="">
                        @elseif ($user->picture == null and $user->id_gender == 2)
                            <img id="my_image" src="{{ asset('storage/imgs/avatar_woman.png') }}" alt="">
                        @else
                            <img id="my_image" src="{{ asset('storage/imgs/' . $user->picture) }}" alt="">
                        @endif
                    </center>
                </div>
                <h1>{{ $user->name }}</h1>
            </div>
            <div class="content-info-profile">
                <div>
                    <b>CORREO</b>
                    <p>{{ $user->email }}</p>
                </div>
                <div><b>TÈLEFONO</b>
                    @if ($user->phone == null)
                        <p>NO REGISTRADO</p>
                    @else
                        <p>{{ $user->phone }}</p>
                    @endif

                </div>
                <div> <b>CIUDAD</b>
                    @if ($city == null)
                        <p>NO REGISTRADO</p>
                    @else
                        <p>{{ $city->city }}</p>
                    @endif
                </div>
                <div><b>FECHA DE NACIMIENTO</b>
                    @if ($user->birthdate == null)
                        <p>NO REGISTRADO</p>
                    @else
                        <p>{{ $user->birthdate }}</p>
                    @endif
                </div>




            </div>
            <div class="content-my-publications">
                <h1>MIS PUBLICACIONES</h1>
                <div class="pictures">
                    @foreach ($my_publications as $mp)
                        <div class="picture-my-pictures">
                            <img src="{{ asset('storage/imgs/' . $mp->picture) }}" alt="">
                        </div>
                    @endforeach
                </div>
                <div class="content-btn-more">
                    <button id="btn_see_more">VER MÀS</button>
                </div>
            </div>
        </div>
        <div class="content-right">
            @foreach ($publications as $p)
                <div class="publication">
                    <div class="publication-header">
                        <div class="publication-info-person">
                            <div class="only_info_person">
                                <div class="picture_publication">
                                    <img src="{{ asset('storage/imgs/' . $p->picture) }}" alt="">
                                </div>
                                <div class="info">
                                    <b>{{ $p->name }}</b>
                                    <p>{{ $p->date }}</p>
                                </div>
                            </div>
                        </div>
                        <div class="publication-description-picture">
                            <p>{{ $p->description }}</p>
                        </div>
                    </div>
                    <div class="publication-content-picture">
                        <img src="{{ asset('storage/imgs/' . $p->picture_publication) }}" alt="">
                    </div>
                    <div class="publication-content-buttons">
                        <div class="content_like">
                            <i class="bi bi-heart-fill"></i>
                            @php
                                $total = 0;
                            @endphp
                            @foreach ($likes as $l)
                                @if ($l->id_publication == $p->id)
                                    $total = $total + 1;
                                @endif
                            @endforeach
                            <p><b>{{ $total }}</b> LIKES </p>
                        </div>
                        <div class="content_comments">
                            <i class="bi bi-chat-left"></i>
                            @php
                                $total = 0;
                            @endphp
                            @foreach ($comments as $c)
                                @if ($c->id_publication == $c->id)
                                    $total = $total + 1;
                                @endif
                            @endforeach
                            <p> <b>{{ $total }}</b> COMENTARIOS </p>
                        </div>
                    </div>

                </div>
            @endforeach



        </div>


    </section>

    <footer class="footer">
        <div class="footer-left">
            <div class="content-logo-footer">
                <img src="{{ asset('storage/icons/logo_FD.png') }}" alt="">
            </div>
            <h1>FRIEND CONNECTION</h1>
        </div>
        <div class="footer-right">
            <P>© 2023 Friend Connection - Todos los Derechos Reservados.</P>
        </div>
    </footer>
@endsection

@section('js')
    <script>
        let rute_form_dates = "{{ route('home.save_dates_user') }}";
        let rute_form_publication = "{{ route('home.save_publication') }}";
    </script>
    @if (session('dates_user'))
        <script>
            Swal.fire(
                'DATOS GURDADOS CON EXISTO',
                'Gracias por tu informaciòn!',
                'success'
            )
        </script>
    @endif

    @if (session('error_dates_publication'))
        <script>
            Swal.fire(
                'ERROR EN LOS DATOS DE PUBLICACIÒN',
                'Hubo un error en la informacion!',
                'error'
            )
        </script>
    @endif

    @if (session('succes_dates_publication'))
        <script>
            Swal.fire(
                'PUBLICACIÒN SUBIDA CON EXISTO',
                'Bien hecho!',
                'success'
            )
        </script>
    @endif

    @vite(['resources/js/home.js'])
@endsection
