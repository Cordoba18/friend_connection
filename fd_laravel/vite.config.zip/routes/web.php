<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PublicationController;
use App\Http\Controllers\LoginController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('login');
});


Route::get('login', [LoginController::class, 'login'])->name('login');
Route::post('login/logueo', [LoginController::class, 'logueo'])->name('login.logueo');

Route::get('/home', [PublicationController::class, 'index'])->name('home');
Route::get('home/loading_departaments', [PublicationController::class, 'loading_departaments'])->name('home.loading_departaments');
Route::get('home/loading_citys/{id}', [PublicationController::class, 'loading_citys'])->name('home.loading_citys');
Route::get('home/loading_dates_user', [PublicationController::class, 'loading_dates_user'])->name('home.loading_dates_user');
Route::post('home/save_dates_user', [PublicationController::class, 'save_dates_user'])->name('home.save_dates_user');
Route::post('home/save_publication', [PublicationController::class, 'save_publication'])->name('home.save_publication');
Route::get('register', [UserController::class, 'register'])->name('register');
Route::post('register/new_user', [UserController::class, 'new_user'])->name('register.new_user');
Route::post('register/validate_email', [UserController::class, 'validate_email'])->name('register.validate_email');
Route::post('delete_user', [UserController::class, 'delete_user'])->name('delete_user');
Route::post('closed_session', [UserController::class, 'closed_session'])->name('closed_session');
