<footer class="footer">
    <div class="footer-left">
        <div class="content-logo-footer">
            <img src="<?php echo e(asset('storage/icons/logo_FD.png')); ?>" alt="">
        </div>
        <h1>FRIEND CONNECTION</h1>
    </div>
    <div class="footer-right">
        <P>© 2023 Friend Connection - Todos los Derechos Reservados.</P>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\friend_connection\fd_laravel\resources\views/layouts/components/footer.blade.php ENDPATH**/ ?>