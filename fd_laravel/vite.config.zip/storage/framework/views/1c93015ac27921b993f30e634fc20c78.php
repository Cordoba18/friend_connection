<?php $__env->startSection('title', 'HOME'); ?>;

<?php $__env->startSection('css'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/home.css']); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <head class="navbar">

    </head>
    <section class="content-home">


        <div class="content-left">
            <div class="content-profile">
                
                <h1>NAME PERSON</h1>
            </div>
            <div class="content-info-profile">

            </div>

            <div class="content-right">

            </div>
        </div>
    </section>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/home.js']); ?>
    <?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fd_laravel\resources\views/homePage.blade.php ENDPATH**/ ?>