<?php $__env->startSection('title', 'HOME'); ?>

<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/home.css']); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <?php echo csrf_field(); ?>

    <div class="contenido">



    </div>

    <?php if($user->name == null || $user->phone == null || $user->id_city == null || $user->birthdate == null): ?>
        <p id="info_validate_dates" hidden>TRUE</p>
        <div class="warning">
            <div class="content_warning">
                <i id="btn_x" class="bi bi-x-circle"></i>
                <div class="message_Warning">
                    <div class="content_logo_message_Warning">
                        <img src="<?php echo e(asset('storage/icons/logo_FD.png')); ?>" alt="">
                    </div>
                    <h1>BIENVENIDO A FRIEND CONNECTION!</h1>
                    <p>Porfavor completa tu informacion de perfil para realizar publicaciones.</p>
                </div>
            </div>
    <?php endif; ?>

    </div>
    <header class="navbar">
        <div class="content-logo-navbar">
            <img src="<?php echo e(asset('storage/icons/logo_FD.png')); ?>" alt="">
        </div>
        <h1>FRIEND CONNECTION</h1>
        <button id="btn_open_menu"><i class="bi bi-person-circle"></i></button>
        <div class="menu" hidden>
            <button>MIS FOTOS</button>
            <button>EDITAR DATOS</button>
            <button>CERRAR SESION</button>
        </div>
    </header>
    <section class="content-home">

        <div class="content-left">
            <div class="content-profile">
                <div class="content-my-picture">
                    <center>
                        <?php if($user->picture == null and $user->id_gender == 1): ?>
                            <img id="my_image" src="<?php echo e(asset('storage/imgs/avatar_men.png')); ?>" alt="">
                        <?php elseif($user->picture == null and $user->id_gender == 2): ?>
                            <img id="my_image" src="<?php echo e(asset('storage/imgs/avatar_woman.png')); ?>" alt="">
                        <?php else: ?>
                            <img id="my_image" src="<?php echo e(asset('storage/imgs/' . $user->picture)); ?>" alt="">
                        <?php endif; ?>
                    </center>
                </div>
                <h1><?php echo e($user->name); ?></h1>
            </div>
            <div class="content-info-profile">
                <div>
                    <b>CORREO</b>
                    <p><?php echo e($user->email); ?></p>
                </div>
                <div><b>TÈLEFONO</b>
                    <?php if($user->phone == null): ?>
                        <p>NO REGISTRADO</p>
                    <?php else: ?>
                        <p><?php echo e($user->phone); ?></p>
                    <?php endif; ?>

                </div>
                <div> <b>CIUDAD</b>
                    <?php if($city == null): ?>
                        <p>NO REGISTRADO</p>
                    <?php else: ?>
                        <p><?php echo e($city->city); ?></p>
                    <?php endif; ?>
                </div>
                <div><b>FECHA DE NACIMIENTO</b>
                    <?php if($user->birthdate == null): ?>
                        <p>NO REGISTRADO</p>
                    <?php else: ?>
                        <p><?php echo e($user->birthdate); ?></p>
                    <?php endif; ?>
                </div>




            </div>
            <div class="content-my-publications">
                <h1>MIS PUBLICACIONES</h1>
                <div class="pictures">
                    <?php $__currentLoopData = $my_publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="picture-my-pictures">
                            <img src="<?php echo e(asset('storage/imgs/' . $mp->picture)); ?>" alt="">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="content-btn-more">
                    <button id="btn_see_more">VER MÀS</button>
                </div>
            </div>
        </div>
        <div class="content-right">
            <?php $__currentLoopData = $publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="publication">
                    <div class="publication-header">
                        <div class="publication-info-person">
                            <div class="only_info_person">
                                <div class="picture_publication">
                                    <img src="<?php echo e(asset('storage/imgs/' . $p->picture)); ?>" alt="">
                                </div>
                                <div class="info">
                                    <b><?php echo e($p->name); ?></b>
                                    <p><?php echo e($p->date); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="publication-description-picture">
                            <p><?php echo e($p->description); ?></p>
                        </div>
                    </div>
                    <div class="publication-content-picture">
                        <img src="<?php echo e(asset('storage/imgs/' . $p->picture_publication)); ?>" alt="">
                    </div>
                    <div class="publication-content-buttons">
                        <div class="content_like">
                            <i class="bi bi-heart-fill"></i>
                            <?php
                                $total = 0;
                            ?>
                            <?php $__currentLoopData = $likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($l->id_publication == $p->id): ?>
                                    $total = $total + 1;
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <p><b><?php echo e($total); ?></b> LIKES </p>
                        </div>
                        <div class="content_comments">
                            <i class="bi bi-chat-left"></i>
                            <?php
                                $total = 0;
                            ?>
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($c->id_publication == $c->id): ?>
                                    $total = $total + 1;
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <p> <b><?php echo e($total); ?></b> COMENTARIOS </p>
                        </div>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>


    </section>

    <footer class="footer">
        <div class="footer-left">
            <div class="content-logo-footer">
                <img src="<?php echo e(asset('storage/icons/logo_FD.png')); ?>" alt="">
            </div>
            <h1>FRIEND CONNECTION</h1>
        </div>
        <div class="footer-right">
            <P>© 2023 Friend Connection - Todos los Derechos Reservados.</P>
        </div>
    </footer>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        let rute_form_dates = "<?php echo e(route('home.save_dates_user')); ?>";
        let rute_form_publication = "<?php echo e(route('home.save_publication')); ?>";
    </script>
    <?php if(session('dates_user')): ?>
        <script>
            Swal.fire(
                'DATOS GURDADOS CON EXISTO',
                'Gracias por tu informaciòn!',
                'success'
            )
        </script>
    <?php endif; ?>

    <?php if(session('error_dates_publication')): ?>
        <script>
            Swal.fire(
                'ERROR EN LOS DATOS DE PUBLICACIÒN',
                'Hubo un error en la informacion!',
                'error'
            )
        </script>
    <?php endif; ?>

    <?php if(session('succes_dates_publication')): ?>
        <script>
            Swal.fire(
                'PUBLICACIÒN SUBIDA CON EXISTO',
                'Bien hecho!',
                'success'
            )
        </script>
    <?php endif; ?>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/home.js']); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fd_laravel\resources\views/customprofile.blade.php ENDPATH**/ ?>