<?php $__env->startSection('title', 'REGISTER'); ?>
<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/form.css']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="content">

        <div class="content-logo">
            <img src="<?php echo e(asset('storage/icons/logo_FD.png')); ?>" alt="">
        </div>
        <?php echo csrf_field(); ?>
        <div class="content-form">
            <h2>REGISTER</h2>
            <form action="" method="POST">

                <label>NOMBRE</label>
                <input class="active_error" id="name" type="text" placeholder="INGRESE SU NOMBRE" name="name" required>
                <label >GENERO</label>
                <select name="gender" id="gender">
                    <option value="">SELECCIONÈ UN GENERO</option>
                    <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($g->id); ?>"><?php echo e($g->gender); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label>CORREO</label>
                <input id="email" type="email" placeholder="INGRESE SU CORREO" name="email" required>
                <label>CONTRASEÑA</label>
                <input id="password1" type="password" placeholder="INGRESE SU CONTRASEÑA" name="password1" required>
                <label> CONFIRMAR CONTRASEÑA</label>
                <input id="password2" type="password" placeholder="INGRESE SU CONTRASEÑA" name="password2" required>
                <p id="error" hidden></p>
                <button id="btn_save_info_register" type="submit">REGISTRAR</button>
                <a href="<?php echo e(route('login')); ?>">Si tengo cuenta</a>
            </form>
        </div>





    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    let route_login = '<?php echo e(route("login")); ?>';
</script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/register.js']); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\friend_connection\fd_laravel\resources\views/register.blade.php ENDPATH**/ ?>