<?php $__env->startSection('title', 'HOME'); ?>

<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/home.css', 'resources/css/detailsprofile.css']); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <p id="my_id" hidden><?php echo e(Auth::user()->id); ?></p>
    <?php echo csrf_field(); ?>

    </div>

    <section class="content-home">

        <div class="content-left">
            <div class="content-profile">
                <div class="content-my-picture">
                    <center>
                        <?php if($user->picture == null and $user->id_gender == 1): ?>
                            <img id="my_image" src="<?php echo e(asset('storage/imgs/avatar_men.png')); ?>" alt="">
                        <?php elseif($user->picture == null and $user->id_gender == 2): ?>
                            <img id="my_image" src="<?php echo e(asset('storage/imgs/avatar_woman.png')); ?>" alt="">
                        <?php else: ?>
                            <img id="my_image" src="<?php echo e(asset('storage/imgs/' . $user->picture)); ?>" alt="">
                        <?php endif; ?>
                    </center>
                </div>
                <h1 id="my_name"><?php echo e($user->name); ?></h1>
            </div>
            <div class="content-info-profile">
                <div>
                    <b>CORREO</b>
                    <p><?php echo e($user->email); ?></p>
                </div>
                <div><b>TÈLEFONO</b>
                    <?php if($user->phone == null): ?>
                        <p>NO REGISTRADO</p>
                    <?php else: ?>
                        <p><?php echo e($user->phone); ?></p>
                    <?php endif; ?>

                </div>
                <div> <b>CIUDAD</b>
                    <?php if($city == null): ?>
                        <p>NO REGISTRADO</p>
                    <?php else: ?>
                        <p><?php echo e($city->city); ?></p>
                    <?php endif; ?>
                </div>
                <div><b>FECHA DE NACIMIENTO</b>
                    <?php if($user->birthdate == null): ?>
                        <p>NO REGISTRADO</p>
                    <?php else: ?>
                        <p><?php echo e($user->birthdate); ?></p>
                    <?php endif; ?>
                </div>




            </div>
        </div>
        <div class="content-right">
            <?php $__currentLoopData = $my_publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="content_publication_edit">
                    <div class="content_publication_edit_header">
                        <b>Descripcion</b>
                        <p><?php echo e($mp->description); ?></p>

                    </div>
                    <div class="content_publication_edit_content_picture">
                        <img src="<?php echo e(asset('storage/imgs/' . $mp->picture)); ?>" alt="">
                    </div>

                    <div class="content_publication_edit_content_info">

                        <div class="content_publication_edit_content_info_left">
                            <div class="content_publication_edit_content_info_left_header">
                                <?php
                                    $total = 0;
                                ?>
                                <?php $__currentLoopData = $likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($l->id_publication == $mp->id): ?>
                                        <?php
                                            $total = $total + 1;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <h1>LIKES <?php echo e($total); ?></h1>
                            </div>
                            <div class="content_publication_edit_content_info_left_all_likes">
                                <?php $__currentLoopData = $likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($l->id_publication == $mp->id): ?>


                                    <div class="content_publication_edit_content_info_left_like">
                                        <div class="content_publication_edit_content_info_left_like_img">
                                            <?php if($l->picture == null and $l->id_gender == 1): ?>
                                                <img id="your_picture" src="<?php echo e(asset('storage/imgs/avatar_men.png')); ?>"
                                                    alt="">
                                            <?php elseif($l->picture == null and $l->id_gender == 2): ?>
                                                <img id="your_picture" src="<?php echo e(asset('storage/imgs/avatar_woman.png')); ?>"
                                                    alt="">
                                            <?php else: ?>
                                                <img id="your_picture" src="<?php echo e(asset('storage/imgs/' . $l->picture)); ?>"
                                                    alt="">
                                            <?php endif; ?>
                                        </div>
                                        <div class="content_publication_edit_content_info_left_like_info">
                                            <h1><?php echo e($l->name); ?></h1>
                                            <b><?php echo e($l->date); ?></b>
                                        </div>
                                    </div>
                                       <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="content_publication_edit_content_info_right">
                            <div class="content_publication_edit_content_info_right_header">
                                <?php
                                    $total = 0;
                                ?>
                                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($c->id_publication == $mp->id): ?>
                                        <?php
                                            $total = $total + 1;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <h1>COMENTARIOS <?php echo e($total); ?></h1>
                            </div>
                            <div class="content_publication_edit_content_info_right_all_comments">
                                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($c->id_publication == $mp->id): ?>
                                    <div class="content_publication_edit_content_info_right_comment">
                                        <div class="content_publication_edit_content_info_right_comment_header">
                                            <div class="content_publication_edit_content_info_right_comment_header_picture">
                                                <?php if($c->picture == null and $c->id_gender == 1): ?>
                                                    <img id="your_picture" src="<?php echo e(asset('storage/imgs/avatar_men.png')); ?>"
                                                        alt="">
                                                <?php elseif($c->picture == null and $c->id_gender == 2): ?>
                                                    <img id="your_picture"
                                                        src="<?php echo e(asset('storage/imgs/avatar_woman.png')); ?>" alt="">
                                                <?php else: ?>
                                                    <img id="your_picture" src="<?php echo e(asset('storage/imgs/' . $c->picture)); ?>"
                                                        alt="">
                                                <?php endif; ?>
                                            </div>
                                            <div
                                                class="content_publication_edit_content_info_right_comment_header_info_person">
                                                <h1><?php echo e($c->name); ?></h1>
                                                <b><?php echo e($c->date); ?></b>
                                            </div>
                                        </div>
                                        <div class="content_publication_edit_content_info_right_comment_full">
                                            <?php echo e($c->comment); ?>

                                            <?php if($mp->id_user == Auth::user()->id): ?>
                                            <form action="<?php echo e(route('home.delete_comment_details')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="text" name="id" hidden value="<?php echo e($c->id_comment); ?>">
                                                <input type="text" name="id_user" hidden value="<?php echo e($mp->id_user); ?>">
                                            <button style="border: 0; background-color: white"><i id="btn_delete_comment" class="bi bi-trash-fill btn btn-danger"></i></button>
                                        </form>
                                            <?php endif; ?>

                                        </div>
                                    </div>

                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>


    </section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        let rute_sond = "<?php echo e(asset('storage/sonds/sonido_like.mp3')); ?>";
        let rute_form_dates = "<?php echo e(route('home.save_dates_user')); ?>";
        let rute_form_publication = "<?php echo e(route('home.save_publication')); ?>";
        let = control_rute_imgs = "<?php echo e(asset('storage/imgs/')); ?>" + "/";
    </script>
    <?php if(session('dates_user')): ?>
        <script>
            Swal.fire(
                'DATOS GURDADOS CON EXISTO',
                'Gracias por tu informaciòn!',
                'success'
            )
        </script>
    <?php endif; ?>

    <?php if(session('error_dates_publication')): ?>
        <script>
            Swal.fire(
                'ERROR EN LOS DATOS DE PUBLICACIÒN',
                'Hubo un error en la informacion!',
                'error'
            )
        </script>
    <?php endif; ?>

    <?php if(session('succes_dates_publication')): ?>
        <script>
            Swal.fire(
                'PUBLICACIÒN SUBIDA CON EXISTO',
                'Bien hecho!',
                'success'
            )
        </script>
    <?php endif; ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/header.js']); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\friend_connection\fd_laravel\resources\views/detailsprofile.blade.php ENDPATH**/ ?>