<header class="navbar">
    <div class="content-logo-navbar">
        <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('storage/icons/logo_FD.png')); ?>" alt=""></a>
    </div>
    <h1>FRIEND CONNECTION</h1>
    <button id="btn_open_menu"><i class="bi bi-person-circle"></i></button>
    <div class="menu" hidden>
        <button>MIS FOTOS</button>
        <button>EDITAR DATOS</button>
        <button>CERRAR SESION</button>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\friend_connection\fd_laravel\resources\views/layouts/components/navbar.blade.php ENDPATH**/ ?>