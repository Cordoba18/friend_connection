<?php $__env->startSection('title', 'HOME'); ?>

<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/home.css']); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<p id="my_id" hidden><?php echo e($user->id); ?></p>
    <?php echo csrf_field(); ?>



    </div>

    <section class="content-home">

        <div class="content-left">
            <div class="content-profile">
                <div class="content-my-picture">
                    <center>
                        <?php if($user->picture == null and $user->id_gender == 1): ?>
                            <img id="my_image" src="<?php echo e(asset('storage/imgs/avatar_men.png')); ?>" alt="">
                        <?php elseif($user->picture == null and $user->id_gender == 2): ?>
                            <img id="my_image" src="<?php echo e(asset('storage/imgs/avatar_woman.png')); ?>" alt="">
                        <?php else: ?>
                            <img id="my_image" src="<?php echo e(asset('storage/imgs/' . $user->picture)); ?>" alt="">
                        <?php endif; ?>
                    </center>
                </div>
                <h1 id="my_name"><?php echo e($user->name); ?></h1>
            </div>
            <div class="content-info-profile">
                <div>
                    <b>CORREO</b>
                    <p><?php echo e($user->email); ?></p>
                </div>
                <div><b>TÈLEFONO</b>
                    <?php if($user->phone == null): ?>
                        <p>NO REGISTRADO</p>
                    <?php else: ?>
                        <p><?php echo e($user->phone); ?></p>
                    <?php endif; ?>

                </div>
                <div> <b>CIUDAD</b>
                    <?php if($city == null): ?>
                        <p>NO REGISTRADO</p>
                    <?php else: ?>
                        <p><?php echo e($city->city); ?></p>
                    <?php endif; ?>
                </div>
                <div><b>FECHA DE NACIMIENTO</b>
                    <?php if($user->birthdate == null): ?>
                        <p>NO REGISTRADO</p>
                    <?php else: ?>
                        <p><?php echo e($user->birthdate); ?></p>
                    <?php endif; ?>
                </div>




            </div>
            <div class="content-my-publications">
                <h1>MIS PUBLICACIONES</h1>
                <div class="pictures">
                    <?php $__currentLoopData = $my_publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="picture-my-pictures">
                            <img src="<?php echo e(asset('storage/imgs/' . $mp->picture)); ?>" alt="">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="content-btn-more">
                    <a href="<?php echo e(route('home.details', $user->id)); ?>" id="btn_see_more">VER DETALLES</a>
                </div>
            </div>
        </div>
        <div class="content-right">
            <?php $__currentLoopData = $publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="publication">
                    <p hidden id="id_publication"><?php echo e($p->id_publication); ?></p>
                    <div class="publication-header">
                        <div class="publication-info-person">
                            <div class="only_info_person">
                                <div class="picture_publication">
                                    <a href="<?php echo e(route('home.details', $p->id)); ?>">
                                    <?php if($p->picture == null and $p->id_gender == 1): ?>
                                        <img id="your_picture" src="<?php echo e(asset('storage/imgs/avatar_men.png')); ?>"
                                            alt="">
                                    <?php elseif($p->picture == null and $p->id_gender == 2): ?>
                                        <img id="your_picture" src="<?php echo e(asset('storage/imgs/avatar_woman.png')); ?>"
                                            alt="">
                                    <?php else: ?>
                                        <img id="your_picture" src="<?php echo e(asset('storage/imgs/' . $p->picture)); ?>"
                                            alt="">
                                    <?php endif; ?>
                                </a>
                                </div>
                                <div class="info">
                                    <b id="name_publication"><?php echo e($p->name); ?></b>
                                    <p id="date_publication"><?php echo e($p->date); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="publication-description-picture">
                            <p id="description_publication"><?php echo e($p->description); ?></p>
                        </div>
                    </div>
                    <div class="publication-content-picture">
                        <img id="image_publication" src="<?php echo e(asset('storage/imgs/' . $p->picture_publication)); ?>"
                            alt="">
                    </div>
                    <div class="publication-content-buttons">
                        <div class="content_like">
                            <?php
                                $validate_like = false;
                            ?>
                            <?php $__currentLoopData = $likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user->id == $l->id_user and $l->id_publication == $p->id_publication): ?>
                                    <?php
                                        $validate_like = true;
                                    ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if($validate_like): ?>
                                <i id="btn_like" style="color: #9376E0;" class="bi bi-heart-fill"></i>
                            <?php else: ?>
                                <i id="btn_like" class="bi bi-heart"></i>
                            <?php endif; ?>
                            <?php
                                $total = 0;
                            ?>
                            <?php $__currentLoopData = $likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($l->id_publication == $p->id_publication): ?>
                                    <?php
                                        $total = $total + 1;
                                    ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <p><b id="count_likes"><?php echo e($total); ?></b> LIKES </p>
                        </div>
                        <div class="content_comments">
                            <i id="btn_comment" class="bi bi-chat-square-fill"></i>
                            <?php
                                $total = 0;
                            ?>
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($c->id_publication == $p->id_publication): ?>
                                    <?php
                                        $total = $total + 1;
                                    ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <p> <b id="count_comments"><?php echo e($total); ?></b> COMENTARIOS </p>
                        </div>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>


    </section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        let rute_sond = "<?php echo e(asset('storage/sonds/sonido_like.mp3')); ?>";
        let rute_form_dates = "<?php echo e(route('home.save_dates_user')); ?>";
        let rute_form_publication = "<?php echo e(route('home.save_publication')); ?>";
        let = control_rute_imgs = "<?php echo e(asset('storage/imgs/')); ?>" + "/";
    </script>
    <?php if(session('dates_user')): ?>
        <script>
            Swal.fire(
                'DATOS GURDADOS CON EXISTO',
                'Gracias por tu informaciòn!',
                'success'
            )
        </script>
    <?php endif; ?>

    <?php if(session('error_dates_publication')): ?>
        <script>
            Swal.fire(
                'ERROR EN LOS DATOS DE PUBLICACIÒN',
                'Hubo un error en la informacion!',
                'error'
            )
        </script>
    <?php endif; ?>

    <?php if(session('succes_dates_publication')): ?>
        <script>
            Swal.fire(
                'PUBLICACIÒN SUBIDA CON EXISTO',
                'Bien hecho!',
                'success'
            )
        </script>
    <?php endif; ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/home.js']); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\friend_connection\fd_laravel\resources\views/customprofile.blade.php ENDPATH**/ ?>