<?php $__env->startSection('title', 'LOGIN'); ?>
<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/form.css']); ?>;
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">

        <div class="content-logo">
            <div class="logo">
                <img src="<?php echo e(asset('storage/icons/logo_FD.png')); ?>" alt="">
            </div>
        </div>

        <div class="content-form">
            <form action="<?php echo e(route('login.logueo')); ?>" method="POST">
                <?php echo csrf_field(); ?>
            <h2>LOGIN</h2>
            <label>CORREO</label>
            <input type="email" placeholder="INGRESE SU CORREO" name="email" required>
            <label>CONTRASEÑA</label>
            <input type="password" placeholder="INGRESE SU CONTRASEÑA" name="password" required>
            <?php if(session('message_error')): ?>
              <p id="error"> <?php echo e(session('message_error')); ?></p>
         <?php endif; ?>
            <button type="submit">ENTRAR</button>
            <a href="<?php echo e(route('register')); ?>">No tengo cuenta</a>
        </form>
        </div>



    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/login.js']); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fd_laravel\resources\views/login.blade.php ENDPATH**/ ?>